""" Module 02 Part 4 Slide 18
    Global Constants and formatting output
"""
QUARTER = 25
DIME = 10
NICKEL = 5
PENNY = 1

numPennies = int(input('Number of pennies? '))
numNickels = int(input('Number of nickels? '))
numDimes = int(input('Number of dimes? '))
numQuarters = int(input('Number of quarters? '))

totalCents = numQuarters * QUARTER + numDimes * DIME    \
            + numNickels * NICKEL + numPennies * PENNY

dollars = totalCents/100
print('$', format(dollars, '.2f'), sep='')
