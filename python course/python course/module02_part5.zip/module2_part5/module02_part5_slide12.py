""" Module 02 Part 5 Slide 12
    Formatting output
"""

name1 = "Sam"
name2 = "Benjamin"
major1 = "computer Science"
major2 = "Math"


outs0 = format('Name', '<15s') + 'Major'
outs1 = format(name1, '<15s') + major1
outs2 = format(name2, '<15s') + major2
print(outs0, '-'*35, outs1, outs2, sep='\n')
