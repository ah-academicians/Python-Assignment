""" Module 02 Part 4 Slide 13
    More output format
"""
MONEY_FORMAT = '8,.2f'
# 8 spaces, 2 decimal places

name1 = "Emeralds"
name2 = "Cupcakes"
price1 = 21358
price2 = 4.59
# Base price is per dozen.  Calculate per each.

price1each = price1/12
price2each = price2/12

outs0 = format('Item', '<15s') + 'Price Each'
outs1 = format(name1, '<15s') + '$' + format(price1each, MONEY_FORMAT)
outs2 = format(name2, '<15s') + '$' + format(price2each, MONEY_FORMAT)
print(outs0, '-'*35, outs1, outs2, sep='\n')
