""" Module 02 Part 5 Slide 8
    USing string concatenation 
"""
first = input('first name: ')
last = input('last name: ') 

combined = 'Student name: ' + last + ', ' + first
print(combined) 
